# Pixels data conversions

Tool that converts the exported pixels of [Pixels v4.3.2](https://teovogel.me/pixels/)
to other formats. Currently the only conversion format is pixels json to csv