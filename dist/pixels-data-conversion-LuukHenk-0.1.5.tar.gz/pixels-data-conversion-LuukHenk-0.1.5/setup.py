"""Run the setup"""
import setuptools

setuptools.setup()
